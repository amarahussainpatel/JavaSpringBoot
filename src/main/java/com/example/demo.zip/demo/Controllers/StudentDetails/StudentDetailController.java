package com.example.demo.Controllers.StudentDetails;

public class StudentDetailController {

}
