package com.example.demo.Services.StudentDetail;

import org.springframework.stereotype.Service;

@Service
public interface StudentDetailInterface {
	
}
