package com.example.demo.Repositories.Student;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;

import com.example.demo.Entities.Student.StudentEntity;

public class StudentRepoClass {


	public void UpdateByPut() {
		// TODO Auto-generated method stub
		
	}

	
	public void UpdateByPatch() {
		// TODO Auto-generated method stub
		
	}

}
