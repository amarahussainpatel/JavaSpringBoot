package com.example.demo.Exceptions;

public class Null_IDException extends Exception {

	public Null_IDException(String message) {
		super(message);
	}
}
