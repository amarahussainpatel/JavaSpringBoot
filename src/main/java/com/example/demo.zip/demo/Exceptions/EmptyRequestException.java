package com.example.demo.Exceptions;

public class EmptyRequestException extends Exception {
	
	public EmptyRequestException(String message) {
		super(message);
	}
}
