package com.example.demo.adapter.Class;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.example.demo.Entities.Classes.ClassEntity;
import com.example.demo.Entities.Student.StudentEntity;
import com.example.demo.adapter.student.StudentAdapter;
import com.example.demo.dto.ClassDTO;
import com.example.demo.dto.StudentDTO;
import com.example.demo.dto.StudentDetailDTO;

public class ClassAdapter {
	
	private StudentAdapter adapterstudent = new StudentAdapter();

	public ClassEntity DTOtoDAO(ClassDTO dto) {
		if(null!=dto) {
			ClassEntity entity = new ClassEntity();
			if(null!=dto.getClassID()) {
				entity.setClassID(dto.getClassID());
			}
			entity.setRoomNo(dto.getRoomNo());
			entity.setSubjectName(dto.getSubjectName());
			if(null!=dto.getJoinedstudents()) {
				Set<StudentEntity> studentSet = new HashSet<>();
				dto.getJoinedstudents().stream().forEach(StudentDTO->{
					studentSet.add(adapterstudent.DTOToDAO(StudentDTO));
				});
				entity.setJoinedstudents(studentSet);
			}
			return entity;
		}
		else {
			return null;
		}
	}
	
	public ClassDTO DAOtoDTO(ClassEntity entity) {
		if(null!=entity) {
			ClassDTO dto = new ClassDTO();
			dto.setClassID(entity.getClassID());
			dto.setRoomNo(entity.getRoomNo());
			dto.setSubjectName(entity.getSubjectName());
			//for students
			if(entity.getJoinedstudents() !=null) {
				List<StudentDTO> studentList= new ArrayList<>();
				entity.getJoinedstudents().stream().forEach(StudentEntity->{
					studentList.add(adapterstudent.DAOToDTO(StudentEntity));
				});
				dto.setJoinedstudents(studentList);
			}
			return dto;
		}
		else {
			return null;
		}
	}
	
	public List<ClassDTO> DAOListToDTOList(List<ClassEntity> list) { //daotodto
		List<ClassDTO> newDto = new ArrayList<>();
		for(ClassEntity entity: list ) {
			ClassDTO newDtoObj = new ClassDTO();
			newDtoObj.setRoomNo(entity.getRoomNo());
			newDtoObj.setSubjectName(entity.getSubjectName());
			newDtoObj.setClassID(entity.getClassID());
			//for student
			if(entity.getJoinedstudents() !=null) {
				List<StudentDTO> studentList= new ArrayList<>();
				entity.getJoinedstudents().stream().forEach(StudentEntity->{
					studentList.add(adapterstudent.DAOToDTO(StudentEntity));
				});
				newDtoObj.setJoinedstudents(studentList);
			}
			newDto.add(newDtoObj);
		}
		return newDto;
	}
}
